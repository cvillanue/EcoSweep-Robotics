/***
EcoSweep – V5 ONE L298N, 4 Motors (Left + Right),
+ Button Start/Stop Toggle 

Button Logic: When the button is pressed, it changes the voltage level on the input pin 
from a defined HIGH state to a LOW state.
***/

// Motor driver pins
int ENA = 5;   
int IN1 = 6;
int IN2 = 7;

int ENB = 3;    
int IN3 = 11;
int IN4 = 12;

// Ultrasonic
int trigPin = 9;
int echoPin = 10;

int stopDistance = 15;

// Adjust speed here (0–255)
int leftSpeed  = 130;   // ~50% power
int rightSpeed = 130;   // ~50% power

//  BUTTON 
const int buttonPin = 2;       // Button wire to D2
bool paused = false;           
bool lastButtonState = HIGH;   //HIGH means the button was not pressed (common when using INPUT_PULLUP).

Tracking the last state helps detect when the button is pressed once, 

void stopMotors() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

void setup() {
  Serial.begin(9600);

  // Left side
  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  // Right side
  pinMode(ENB, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // Ultrasonic
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  // Button (uses internal pull-up resistor)
  pinMode(buttonPin, INPUT_PULLUP);

  // Enable motors at lower speed
  analogWrite(ENA, leftSpeed);  
  analogWrite(ENB, rightSpeed);  

  // Start stopped
  stopMotors();
  Serial.println("EcoSweep Ready. Press button to RUN.");
}

void loop() {

  // BUTTON CHECK FOR DEBUGGING!!! 
  bool currentButtonState = digitalRead(buttonPin);

  // Detect a button press (HIGH - > LOW)
  //The button was not pressed before & The button is pressed now
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    paused = !paused;   

    if (paused) Serial.println("PAUSED (STOP)");
    else        Serial.println("RUNNING");

    delay(200); //(prevents double toggles)
  }
  lastButtonState = currentButtonState;

  // If paused, keep motors stopped and skip ultrasonic logic
  if (paused) {
    stopMotors();
    delay(50);
    return;
  }

  long duration;
  float distance;

  // ultrasonic
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0) distance = 999;
  else distance = duration * 0.034 / 2.0;

  Serial.print("Distance: ");
  Serial.println(distance);

  // Drive logic
  if (distance > stopDistance) {
    // FORWARD (low speed)
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, HIGH);
    digitalWrite(IN4, LOW);

  } else {
    stopMotors();
  }

  delay(100);
}
