/***
EcoSweep – V4 ONE L298N, 4 Motors (Left + Right), Slow + Smooth Speed
***/

// Motor driver pins
int ENA = 5;   
int IN1 = 6;
int IN2 = 7;

int ENB = 3;    
int IN3 = 11;
int IN4 = 12;

// Ultrasonic
int trigPin = 9;
int echoPin = 10;

int stopDistance = 15;

// Adjust speed here (0–255)
int leftSpeed  = 130;   // ~50% power
int rightSpeed = 130;   // ~50% power

void setup() {
  Serial.begin(9600);

  // Left side
  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  // Right side
  pinMode(ENB, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // Ultrasonic
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  // Enable motors at lower speed
  analogWrite(ENA, leftSpeed);  
  analogWrite(ENB, rightSpeed);  
}

void loop() {
  long duration;
  float distance;

  // --- ULTRASONIC PING ---
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0) distance = 999;
  else distance = duration * 0.034 / 2.0;

  Serial.print("Distance: ");
  Serial.println(distance);

  // DRIVE LOGIC 
  if (distance > stopDistance) {
    // FORWARD (low speed)
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, HIGH);
    digitalWrite(IN4, LOW);

  } else {
    // STOP
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, LOW);
    digitalWrite(IN4, LOW);
  }

  delay(100);
}
