/***
Version 3 Code - EcoSweep
4 DC Motors, 2 L298N Motor Drivers, Ultrasonic Stop

DISCLAIMER: THIS version of the code had issues with the VIN -> 5V (the common ground issue was resolved however 
the motor wasnt moving givin the VIN to 5V (need to add an alternative pin))
***/


int ENA  = 5;    // Enable for Motor A (left front)
int IN1  = 6;
int IN2  = 7;

int ENB  = 3;    // Enable for Motor B (left back)
int IN3  = 11;
int IN4  = 12;

// New pins for the second L298N
int ENA2 = 4;    // Enable for Motor A (right front)
int IN1_2 = 2;
int IN2_2 = 8;

int ENB2 = 13;   
int IN3_2 = A0;  
int IN4_2 = A1;

int trigPin = 9;
int echoPin = 10;

// Distance threshold in cm
int stopDistance = 15;

void setup() {
  Serial.begin(9600);

//driver 1
  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENB, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // driver 2
  pinMode(ENA2, OUTPUT);
  pinMode(IN1_2, OUTPUT);
  pinMode(IN2_2, OUTPUT);

  pinMode(ENB2, OUTPUT);
  pinMode(IN3_2, OUTPUT);
  pinMode(IN4_2, OUTPUT);

  // -------- Ultrasonic pins --------
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  // Enable ALL motors (full speed for now)
  // EN pins act as "master ON/OFF" for each motor
  digitalWrite(ENA, HIGH);
  digitalWrite(ENB, HIGH);
  digitalWrite(ENA2, HIGH);
  digitalWrite(ENB2, HIGH);
}

void loop() {
  long duration;
  float distance;

  // ultrasonic pins
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH);
  distance = duration * 0.034 / 2.0; // Convert to cm

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // motor logic
  if (distance > stopDistance || distance == 0) {
    // No object detected → ALL 4 MOTORS FORWARD

    // LEFT SIDE (Driver 1)
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    digitalWrite(IN3, HIGH);
    digitalWrite(IN4, LOW);

    // RIGHT SIDE (Driver 2)
    digitalWrite(IN1_2, HIGH);
    digitalWrite(IN2_2, LOW);

    digitalWrite(IN3_2, HIGH);
    digitalWrite(IN4_2, LOW);

  } else {
    // Object detected → STOP ALL 4 MOTORS

    // LEFT SIDE (Driver 1)
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
    digitalWrite(IN3, LOW);
    digitalWrite(IN4, LOW);

    // RIGHT SIDE (Driver 2)
    digitalWrite(IN1_2, LOW);
    digitalWrite(IN2_2, LOW);
    digitalWrite(IN3_2, LOW);
    digitalWrite(IN4_2, LOW);
  }

  delay(100);
}
